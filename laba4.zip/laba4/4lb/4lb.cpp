﻿#include <iostream>

using namespace std;

extern "C" float funcasm(int x, int n);  // Объявление внешней функции

int main()
{
    int x, n;
    x = 1;
    cout << "x=1 " << endl; //Вывод текста
    cout << "Input n: " << endl;//Вывод текста
    cin >> n; //Ввод х

  


    float R = funcasm(x,n);//результат  
          
    cout << "Result: " << R << endl;//вывод результата
    return 0;

}

